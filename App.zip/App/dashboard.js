document.getElementById("student-list").innerHTML = `
    <table>
        <tr>
            <th>Name</th>
            <th>Test Attempts</th>
            <th>Marks</th>
        </tr>
        <tr>
            <td>Student A</td>
            <td>3</td>
            <td>85%</td>
        </tr>
        <tr>
            <td>Student B</td>
            <td>2</td>
            <td>78%</td>
        </tr>
    </table>
`;
