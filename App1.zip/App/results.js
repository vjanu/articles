document.getElementById("score").textContent = "80%";
document.getElementById("correct-answers").innerHTML = `
    <p>Q1: Correct!</p>
    <p>Q2: Correct!</p>
`;
