let currentQuestion = 0;
const questions = [
    {
        question: "What is 2 + 2?",
        options: ["3", "4", "5", "6"],
        answer: 1,
        explanation: "2 + 2 equals 4."
    },
    {
        question: "What is the identity matrix for 2x2?",
        options: ["[1, 0; 0, 1]", "[1, 1; 1, 1]", "[0, 0; 0, 0]", "[1, 0; 0, 0]"],
        answer: 0,
        explanation: "The identity matrix is a square matrix with ones on the diagonal and zeros elsewhere."
    }
];

function loadQuestion() {
    let q = questions[currentQuestion];
    let questionContainer = document.getElementById('question-container');
    questionContainer.innerHTML = `
        <h3>${q.question}</h3>
        ${q.options.map((option, index) => `
            <button onclick="checkAnswer(${index})">${option}</button>
        `).join('')}
    `;
}

function checkAnswer(selected) {
    let q = questions[currentQuestion];
    let result = document.createElement('p');
    if (selected === q.answer) {
        result.innerHTML = "Correct! <button onclick='showExplanation()'>View Explanation</button>";
        result.style.color = "green";
    } else {
        result.innerHTML = `Wrong! Explanation: ${q.explanation}`;
        result.style.color = "red";
    }
    document.getElementById('question-container').appendChild(result);
}

function showExplanation() {
    alert(questions[currentQuestion].explanation);
}

function nextQuestion() {
    currentQuestion++;
    if (currentQuestion < questions.length) {
        loadQuestion();
    } else {
        window.location.href = 'results.html';
    }
}

window.onload = loadQuestion;
