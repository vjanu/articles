document.getElementById("signup-form").addEventListener("submit", function(event) {
    event.preventDefault();

    const name = document.getElementById("name").value;
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirm-password").value;

    // Simple validation for password match
    if (password !== confirmPassword) {
        alert("Passwords do not match!");
        return;
    }

    // Mock API to save user details (could use localStorage for now)
    const users = JSON.parse(localStorage.getItem("users")) || [];
    const userExists = users.some(user => user.username === username);

    if (userExists) {
        alert("Username already exists! Please choose another.");
    } else {
        users.push({ name, username, password });
        localStorage.setItem("users", JSON.stringify(users));
        alert("Sign up successful! You can now log in.");
        window.location.href = "login.html";
    }
});
